package com.supplyco.jsonqr.dao;

public interface AdminDao {

}
